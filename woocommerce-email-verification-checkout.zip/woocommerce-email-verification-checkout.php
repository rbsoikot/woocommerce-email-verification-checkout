<?php
/**
 * Plugin Name: WooCommerce Email Verification on Checkout
 * Description: Prevents order placement until the user verifies their email directly on the checkout page.
 * Version: 1.0
 * Author: Your Name
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// Include necessary files
include_once 'includes/class-email-verification-checkout.php';

// Initialize the plugin
function wcev_initialize_plugin() {
    new WCEV_Email_Verification_Checkout();
}
add_action('plugins_loaded', 'wcev_initialize_plugin');
