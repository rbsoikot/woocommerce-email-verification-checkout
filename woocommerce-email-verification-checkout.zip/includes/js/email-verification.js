jQuery(document).ready(function($) {
    $('#resend_verification_code').on('click', function() {
        var email = $('#billing_email').val();

        if (!email) {
            alert('Please enter your email first.');
            return;
        }

        $.ajax({
            url: email_verification_params.ajax_url,
            type: 'POST',
            data: {
                action: 'resend_verification_code',
                email: email
            },
            success: function(response) {
                if (response.success) {
                    $('#verification_code_status').html('<p style="color:green;">' + response.data + '</p>');
                } else {
                    $('#verification_code_status').html('<p style="color:red;">' + response.data + '</p>');
                }
            }
        });
    });
});
