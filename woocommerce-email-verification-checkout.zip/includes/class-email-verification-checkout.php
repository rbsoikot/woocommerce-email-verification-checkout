<?php

class WCEV_Email_Verification_Checkout {
    private $expiration_time = 600; // Set expiration time to 600 seconds (10 minutes)

    public function __construct() {
        add_action('woocommerce_after_checkout_billing_form', array($this, 'add_verification_field'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('woocommerce_checkout_process', array($this, 'validate_verification_code'));
        add_action('woocommerce_checkout_order_processed', array($this, 'send_verification_code'));
        add_action('wp_ajax_resend_verification_code', array($this, 'resend_verification_code'));
        add_action('wp_ajax_nopriv_resend_verification_code', array($this, 'resend_verification_code'));
    }

    // Add the verification code field to the checkout page
    public function add_verification_field($checkout) {
        echo '<div id="email_verification_field">';
        woocommerce_form_field('email_verification_code', array(
            'type' => 'text',
            'class' => array('form-row-wide'),
            'label' => __('Verification Code'),
            'placeholder' => __('Enter the code sent to your email'),
        ), $checkout->get_value('email_verification_code'));
        echo '<button type="button" id="resend_verification_code" class="button alt">Send Code</button>';
        echo '<p id="verification_code_status"></p>';
        echo '</div>';
    }

    // Enqueue JavaScript to handle resend functionality
    public function enqueue_scripts() {
        wp_enqueue_script('email-verification', plugin_dir_url(__FILE__) . 'js/email-verification.js', array('jquery'), null, true);
        wp_localize_script('email-verification', 'email_verification_params', array(
            'ajax_url' => admin_url('admin-ajax.php'),
        ));
    }

    // Send verification code when the order is processed
    public function send_verification_code($order_id) {
        $order = wc_get_order($order_id);
        $email = $order->get_billing_email();

        if (!$this->is_email_verified($email)) {
            $verification_code = $this->generate_verification_code($email);
            $this->send_verification_email($email, $verification_code);
        }
    }

    // Validate the entered verification code during checkout
    public function validate_verification_code() {
        $email = sanitize_email($_POST['billing_email']);
        $entered_code = sanitize_text_field($_POST['email_verification_code']);

        if (!$this->is_email_verified($email)) {
            $stored_code = get_option('wcev_verification_code_' . $email);
            $expiration_time = get_option('wcev_verification_code_expiration_' . $email); // Get expiration time

            if (time() > $expiration_time) {
                wc_add_notice(__('The verification code has expired. Please request a new code.'), 'error');
            } elseif ($entered_code !== $stored_code) {
                wc_add_notice(__('The email verification code is incorrect.'), 'error');
            }
        }
    }

    // Resend verification code via AJAX
    public function resend_verification_code() {
        $email = sanitize_email($_POST['email']);
        if ($email && is_email($email)) {
            $verification_code = $this->generate_verification_code($email);
            $this->send_verification_email($email, $verification_code);
            wp_send_json_success('Verification code resent to ' . $email);
        } else {
            wp_send_json_error('Invalid email address');
        }
    }

    // Check if email is verified
    private function is_email_verified($email) {
        return get_option('wcev_email_verified_' . $email, false);
    }

    // Generate and store verification code with expiration
    private function generate_verification_code($email) {
        $code = wp_generate_password(6, false, false);
        update_option('wcev_verification_code_' . $email, $code);
        update_option('wcev_verification_code_expiration_' . $email, time() + $this->expiration_time); // Store expiration time
        return $code;
    }

    // Send verification email
    private function send_verification_email($email, $code) {
        $subject = 'Your Email Verification Code';
        $message = 'Your verification code is: ' . $code;
        wp_mail($email, $subject, $message);
    }
}

// Initialize the plugin
if (!function_exists('wcev_initialize_plugin')) {
    function wcev_initialize_plugin() {
        new WCEV_Email_Verification_Checkout();
    }
}

add_action('plugins_loaded', 'wcev_initialize_plugin');